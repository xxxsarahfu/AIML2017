#Default_train.sh
#!/bin/bash
python2.7 train.py $1

