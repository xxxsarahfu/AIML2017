#Default_predict.sh
#!/bin/bash
python2.7 predict.py $1 $2

